#include<iostream>
using namespace std;
int main(){
	 for (char c = 65; c <= 90; ++c) 
        cout << c << " "; 
    cout << endl; 
     for (char c = 97; c <= 122; ++c) 
        cout << c << " ";
    cout << endl; 
    //////////////////
    char ch;
    cin>>ch;
    cout<<int(ch);
  
    cout << endl; 
}
