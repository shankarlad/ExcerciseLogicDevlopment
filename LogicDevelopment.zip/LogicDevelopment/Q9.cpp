#include<iostream>
using namespace std;

int main(){
	char ch;
	cin>>ch;
	if(ch == 'i' || ch == 'o' || ch == 'u' || ch == 'e' || ch == 'a'){
		cout<<"vowel";
	}else if(ch == 'I' || ch == 'O' || ch == 'U' || ch == 'E' || ch == 'A'){
		cout<<"vowel";
	}else{
		cout<<"consonant";
		
	}
return 0;	
}
